Config server Helm chart assumes that git repo with properties exists and is mounted on NFS. 


