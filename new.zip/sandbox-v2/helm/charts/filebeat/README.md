Some modifications have been made to the original Filebeat code:

* `test`, `examples`, Makefile removed.
* Filters have been added in `values.templates.j2`. Review them carefully and modify if needed.
