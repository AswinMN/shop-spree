Default max_connections was 100.  We have increased it to 1000 as connections were exceeding this limit.
