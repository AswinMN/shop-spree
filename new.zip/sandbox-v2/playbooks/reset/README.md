The ymls here delete persistent data of each of the modules.
