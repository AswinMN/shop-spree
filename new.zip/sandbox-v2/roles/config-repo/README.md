The tasks here create a config Git local repository on a mounted file system on console.  The properties are copied from `mosip-infra/deployment/sandbox-v2/roles/config-repo/files/properties`.    

