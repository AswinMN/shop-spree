Tasks here install a chart using helm.
