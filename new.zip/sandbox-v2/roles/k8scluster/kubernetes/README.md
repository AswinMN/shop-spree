Kubernetes dashboard has been enabled in non-password mode.  See dashboard.yml.  Disable in production. 
