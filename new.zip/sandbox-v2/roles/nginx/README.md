For nginx to operate properly make sure selinux is in 'Permissive' mode.  The same is done via playbook `console.yml`.
